package com.example.stackandheap;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener {
    // An int variable to hold a value
    private int value = 0;
    // A bunch of Buttons and a TextView
    private Button btnAdd;
    private Button btnTake;
    private TextView txtValue;
    private Button btnGrow;
    private Button btnShrink;
    private Button btnReset;
    private Button btnHide;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Get a reference to all the buttons in our UI
// Match them up to all our Button objects we declared earlier

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        //Reference
        btnAdd = findViewById(R.id.btnAdd);
        btnTake = findViewById(R.id.btnTake);
        txtValue = findViewById(R.id.txtValue);
        btnGrow = findViewById(R.id.btnGrow);
        btnShrink = findViewById(R.id.btnShrink);
        btnReset = findViewById(R.id.btnReset);
        btnHide = findViewById(R.id.btnHide);


        //Listen
        btnAdd.setOnClickListener(this);
        btnTake.setOnClickListener(this);
        txtValue.setOnClickListener(this);
        btnGrow.setOnClickListener(this);
        btnShrink.setOnClickListener(this);
        btnReset.setOnClickListener(this);
        btnHide.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        // A local variable to use later
        float size;
        if(view.getId() == R.id.btnAdd){
            value ++;
            txtValue.setText(""+ value);
        } else if (view.getId() == R.id.btnTake) {
            value --;
            txtValue.setText(""+ value);
        } else if (view.getId() == R.id.btnReset) {
            value = 0;
            txtValue.setText(""+ value);
        } else if (view.getId() == R.id.btnGrow) {
            size = txtValue.getTextScaleX();
            txtValue.setTextScaleX(size + 1);

        } else if (view.getId() == R.id.btnShrink) {
            size = txtValue.getTextScaleX();
            txtValue.setTextScaleX(size - 1);

        } else if (view.getId() == R.id.btnHide) {
            if(txtValue.getVisibility() == View.VISIBLE)
            {
                // Currently visible so hide it
                txtValue.setVisibility(View.INVISIBLE);
                // Change text on the button
                btnHide.setText("SHOW");
            }else{
                // Currently hidden so show it
                txtValue.setVisibility(View.VISIBLE);
                // Change text on the button
                btnHide.setText("HIDE");
            }
        }
    }
}